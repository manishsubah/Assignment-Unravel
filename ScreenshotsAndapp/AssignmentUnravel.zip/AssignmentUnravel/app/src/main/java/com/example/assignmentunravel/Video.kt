package com.example.assignmentunravel

class Video (
    var url : String
)