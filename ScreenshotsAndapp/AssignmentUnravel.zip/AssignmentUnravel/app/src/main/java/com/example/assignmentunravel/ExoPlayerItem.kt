package com.example.assignmentunravel

import com.google.android.exoplayer2.ExoPlayer

class ExoPlayerItem(
    var exoPlayer: ExoPlayer,
    var position: Int
)